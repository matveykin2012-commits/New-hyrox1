import { useState, useEffect } from "react";

const WEEKS = 8;

const PROGRAM = {
  mon: {
    label: "ПН", title: "Full Body Strength", tag: "СИЛА", color: "#C8FF00",
    focus: "Строим силовую базу. Техника > вес.",
    blocks: [
      { name: "Back Squat", sets: 4, reps: "6", unit: "повт", progression: "kg" },
      { name: "Bench Press", sets: 4, reps: "6", unit: "повт", progression: "kg" },
      { name: "Pull-ups", sets: 3, reps: "8-10", unit: "повт", progression: "body" },
      { name: "Romanian Deadlift", sets: 3, reps: "8", unit: "повт", progression: "kg" },
      { name: "Farmer Carry", sets: 4, reps: "40м", unit: "", progression: "kg" },
    ],
  },
  tue: {
    label: "ВТ", title: "Intervals / Threshold", tag: "БЕГ", color: "#FF4D4D",
    focus: "Повышаем лактатный порог. Только вторник — тяжело.",
    blocks: [
      { name: "Разминка", sets: 1, reps: "1км", unit: "", progression: "pace" },
      { name: "Интервалы 800м @ порог", sets: null, reps: "4×800м", unit: "", progression: "reps" },
      { name: "Восстановление между", sets: 1, reps: "2 мин", unit: "лёгкий бег", progression: null },
      { name: "Заминка", sets: 1, reps: "1км", unit: "", progression: "pace" },
    ],
  },
  wed: {
    label: "СР", title: "Active Recovery", tag: "ВОССТ", color: "#888888",
    focus: "Буфер между нагрузками. Двигаться, не грузить.",
    blocks: [
      { name: "Ходьба / лёгкий велосипед", sets: 1, reps: "20-30 мин", unit: "", progression: null },
      { name: "Мобильность", sets: 1, reps: "15 мин", unit: "", progression: null },
      { name: "Foam rolling", sets: 1, reps: "10 мин", unit: "", progression: null },
    ],
  },
  thu: {
    label: "ЧТ", title: "Lower Body + Easy Run", tag: "ДВОЙНАЯ", color: "#FF9900",
    focus: "Сила низа утром, зона 2 вечером. 4-6ч между.",
    blocks: [
      { name: "Deadlift", sets: 3, reps: "5", unit: "повт", progression: "kg" },
      { name: "Incline DB Bench", sets: 3, reps: "8-10", unit: "повт", progression: "kg" },
      { name: "Seated Row", sets: 3, reps: "10", unit: "повт", progression: "kg" },
      { name: "Walking Lunges", sets: 3, reps: "10/ногу", unit: "", progression: "kg" },
      { name: "Farmer Carry", sets: 3, reps: "40м", unit: "", progression: "kg" },
      { name: "— Easy Run (вечер)", sets: 1, reps: "4-6км", unit: "зона 2", progression: "pace" },
    ],
  },
  fri: {
    label: "ПТ", title: "Hyrox Strength Endurance", tag: "HYROX", color: "#C8FF00",
    focus: "3×10 мин AMRAP. Отдых 2-3 мин между блоками.",
    blocks: [
      { name: "300м Ski Erg", sets: null, reps: "в каждом блоке", unit: "", progression: null },
      { name: "20 Burpee Broad Jumps", sets: null, reps: "", unit: "", progression: null },
      { name: "20 Wall Balls", sets: null, reps: "", unit: "", progression: "kg" },
      { name: "20м Sled Push", sets: null, reps: "", unit: "", progression: "kg" },
      { name: "20м Sled Pull", sets: null, reps: "", unit: "", progression: "kg" },
      { name: "40м Farmers Carry", sets: null, reps: "", unit: "", progression: "kg" },
      { name: "20 Walking Lunges", sets: null, reps: "", unit: "", progression: null },
    ],
  },
  sat: {
    label: "СБ", title: "Long Run", tag: "БАЗА", color: "#4DAAFF",
    focus: "Аэробная база. Строго зона 2. Можно последние 2-3км чуть быстрее.",
    blocks: [
      { name: "Easy Run Zone 2", sets: 1, reps: "10-14км", unit: "", progression: "distance" },
    ],
  },
  sun: {
    label: "ВС", title: "Rest", tag: "ОТДЫХ", color: "#555555",
    focus: "Полное восстановление. Нет — значит нет.",
    blocks: [],
  },
};

const DAYS_ORDER = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];

const WEEK_PROGRESSIONS = {
  1: { label: "Неделя 1", note: "Базовые веса. Освоение паттернов." },
  2: { label: "Неделя 2", note: "+2.5кг на штанге. Интервалы: 4×800м." },
  3: { label: "Неделя 3", note: "+2.5кг. Интервалы: 5×800м. Long run +1км." },
  4: { label: "Неделя 4", note: "Разгрузка. -10% от рабочих весов." },
  5: { label: "Неделя 5", note: "+5кг от нед.3. Hyrox: считай раунды." },
  6: { label: "Неделя 6", note: "+2.5кг. Порог: 3×1км вместо 800м." },
  7: { label: "Неделя 7", note: "+2.5кг. Long run до 14км. Hyrox: меньше отдыха." },
  8: { label: "Неделя 8", note: "Тест неделя. Тяжёлый ПН/ВТ. Остальное лёгкое." },
};

function load(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
function save(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

export default function App() {
  const [activeDay, setActiveDay] = useState("mon");
  const [currentWeek, setCurrentWeek] = useState(() => load("hyrox-week", 1));
  const [completedDays, setCompletedDays] = useState(() => load("hyrox-completed", {}));
  const [notes, setNotes] = useState(() => load("hyrox-notes", {}));

  function changeWeek(w) {
    setCurrentWeek(w);
    save("hyrox-week", w);
  }

  function toggleDay(dayKey) {
    const k = `w${currentWeek}-${dayKey}`;
    const next = { ...completedDays, [k]: !completedDays[k] };
    setCompletedDays(next);
    save("hyrox-completed", next);
  }

  function saveNote(dayKey, text) {
    const k = `w${currentWeek}-${dayKey}`;
    const next = { ...notes, [k]: text };
    setNotes(next);
    save("hyrox-notes", next);
  }

  const weekDoneCount = DAYS_ORDER.filter(d => completedDays[`w${currentWeek}-${d}`]).length;
  const weekProgress = Math.round((weekDoneCount / 5) * 100);
  const weekInfo = WEEK_PROGRESSIONS[currentWeek];
  const day = PROGRAM[activeDay];
  const isDone = completedDays[`w${currentWeek}-${activeDay}`];
  const noteKey = `w${currentWeek}-${activeDay}`;

  return (
    <div style={{ background: "#0a0a0a", minHeight: "100vh", color: "#fff", fontFamily: "'Inter', system-ui, sans-serif", maxWidth: 480, margin: "0 auto", paddingBottom: 40 }}>

      {/* Header */}
      <div style={{ padding: "20px 20px 0", borderBottom: "1px solid #1a1a1a" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 11, color: "#C8FF00", letterSpacing: 3, fontWeight: 700, textTransform: "uppercase" }}>Hybrid Hyrox</div>
            <div style={{ fontSize: 22, fontWeight: 800, lineHeight: 1.1, marginTop: 4 }}>8-недельный план</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11, color: "#555", textTransform: "uppercase", letterSpacing: 1 }}>неделя</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: "#C8FF00", lineHeight: 1 }}>{currentWeek}</div>
            <div style={{ fontSize: 10, color: "#555" }}>из {WEEKS}</div>
          </div>
        </div>

        <div style={{ marginTop: 14, marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
            <span style={{ fontSize: 11, color: "#555" }}>{weekInfo.note}</span>
            <span style={{ fontSize: 11, color: "#C8FF00" }}>{weekDoneCount}/5 сессий</span>
          </div>
          <div style={{ background: "#1a1a1a", borderRadius: 2, height: 3 }}>
            <div style={{ background: "#C8FF00", height: 3, borderRadius: 2, width: `${weekProgress}%`, transition: "width 0.3s" }} />
          </div>
        </div>

        <div style={{ display: "flex", gap: 6, paddingBottom: 16 }}>
          <button onClick={() => changeWeek(Math.max(1, currentWeek - 1))} disabled={currentWeek === 1}
            style={{ flex: 1, background: "#1a1a1a", border: "none", color: currentWeek === 1 ? "#333" : "#fff", padding: "8px 0", borderRadius: 6, fontSize: 13, cursor: currentWeek === 1 ? "default" : "pointer" }}>← Пред</button>
          <button onClick={() => changeWeek(Math.min(WEEKS, currentWeek + 1))} disabled={currentWeek === WEEKS}
            style={{ flex: 1, background: "#1a1a1a", border: "none", color: currentWeek === WEEKS ? "#333" : "#fff", padding: "8px 0", borderRadius: 6, fontSize: 13, cursor: currentWeek === WEEKS ? "default" : "pointer" }}>След →</button>
        </div>
      </div>

      {/* Day tabs */}
      <div style={{ display: "flex", padding: "14px 20px 0", gap: 6 }}>
        {DAYS_ORDER.map(d => {
          const dp = PROGRAM[d];
          const done = completedDays[`w${currentWeek}-${d}`];
          const isActive = activeDay === d;
          return (
            <button key={d} onClick={() => setActiveDay(d)}
              style={{
                flex: 1, padding: "8px 0", borderRadius: 8, border: "none", cursor: "pointer",
                background: isActive ? dp.color : "#111",
                color: isActive ? "#000" : done ? dp.color : "#444",
                fontWeight: 800, fontSize: 10, letterSpacing: 0.5,
                position: "relative", transition: "all 0.15s"
              }}>
              {dp.label}
              {done && !isActive && <span style={{ position: "absolute", top: 2, right: 2, width: 4, height: 4, borderRadius: "50%", background: dp.color }} />}
            </button>
          );
        })}
      </div>

      {/* Day content */}
      <div style={{ padding: "16px 20px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 10, color: day.color, letterSpacing: 3, fontWeight: 700, textTransform: "uppercase" }}>{day.tag}</div>
            <div style={{ fontSize: 20, fontWeight: 800, marginTop: 2 }}>{day.title}</div>
            <div style={{ fontSize: 12, color: "#666", marginTop: 4, lineHeight: 1.4 }}>{day.focus}</div>
          </div>
          {day.blocks.length > 0 && (
            <button onClick={() => toggleDay(activeDay)}
              style={{
                marginLeft: 12, flexShrink: 0, width: 44, height: 44, borderRadius: "50%",
                border: `2px solid ${isDone ? day.color : "#333"}`,
                background: isDone ? day.color : "transparent", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 18, transition: "all 0.2s", color: isDone ? "#000" : "#555"
              }}>
              {isDone ? "✓" : "○"}
            </button>
          )}
        </div>

        {day.blocks.length > 0 ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {day.blocks.map((b, i) => (
              <div key={i} style={{ background: "#111", borderRadius: 10, padding: "12px 14px", borderLeft: `3px solid ${day.color}33` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{b.name}</div>
                  <div style={{ textAlign: "right" }}>
                    {b.sets && <span style={{ fontSize: 12, color: day.color, fontWeight: 700 }}>{b.sets}×</span>}
                    {b.reps && <span style={{ fontSize: 12, color: "#aaa", marginLeft: 2 }}>{b.reps}</span>}
                    {b.unit && <span style={{ fontSize: 10, color: "#555", marginLeft: 4 }}>{b.unit}</span>}
                  </div>
                </div>
                {b.progression && (
                  <div style={{ fontSize: 10, color: "#444", marginTop: 4 }}>
                    {b.progression === "kg" && `Прогрессия: +2.5кг каждые 2 недели`}
                    {b.progression === "pace" && "Темп: комфортный, можешь говорить"}
                    {b.progression === "reps" && `Нед ${currentWeek}: ${currentWeek <= 3 ? "4" : currentWeek <= 5 ? "5" : "5"}×800м`}
                    {b.progression === "distance" && `Нед ${currentWeek}: цель ${8 + Math.min(currentWeek - 1, 6)}км`}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div style={{ background: "#111", borderRadius: 10, padding: "20px 14px", textAlign: "center", color: "#333", fontSize: 13 }}>
            Отдых. Это тоже тренировка.
          </div>
        )}

        {day.blocks.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 11, color: "#444", marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>Заметки</div>
            <textarea
              value={notes[noteKey] || ""}
              onChange={e => saveNote(activeDay, e.target.value)}
              placeholder="Веса, самочувствие, время..."
              style={{
                width: "100%", minHeight: 72, background: "#111", border: "1px solid #1d1d1d",
                borderRadius: 8, color: "#aaa", fontSize: 12, padding: "10px 12px",
                resize: "vertical", boxSizing: "border-box", fontFamily: "inherit"
              }}
            />
          </div>
        )}

        <div style={{ marginTop: 20, background: "#111", borderRadius: 10, padding: "12px 14px", borderLeft: "3px solid #C8FF00" }}>
          <div style={{ fontSize: 10, color: "#C8FF00", letterSpacing: 2, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>
            {weekInfo.label} — фокус
          </div>
          <div style={{ fontSize: 12, color: "#888", lineHeight: 1.6 }}>{weekInfo.note}</div>
        </div>

        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 11, color: "#333", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>Прогресс программы</div>
          <div style={{ display: "flex", gap: 4 }}>
            {Array.from({ length: WEEKS }, (_, i) => {
              const w = i + 1;
              const done = DAYS_ORDER.filter(d => completedDays[`w${w}-${d}`]).length;
              const isCurrent = w === currentWeek;
              return (
                <button key={w} onClick={() => changeWeek(w)}
                  style={{
                    flex: 1, height: 28, borderRadius: 4, border: "none", cursor: "pointer",
                    background: isCurrent ? "#C8FF00" : done >= 4 ? "#1a3300" : done > 0 ? "#1a1a00" : "#111",
                    color: isCurrent ? "#000" : "#555", fontSize: 10, fontWeight: 800,
                  }}>
                  {w}
                </button>
              );
            })}
          </div>
        </div>

        <div style={{ marginTop: 24, fontSize: 10, color: "#222", textAlign: "center" }}>
          данные сохраняются локально · Mat Hybrid Program
        </div>
      </div>
    </div>
  );
}
